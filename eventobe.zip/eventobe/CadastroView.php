
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilo.css">
    <script >
      function ConfereSenha(){

        const senha = document.querySelector('input[name=senha]');
        const confirma = document.querySelector('input[name=confirma]');

        if(confirma.value===senha.value){
          confirma.setCustomValidity('');
        }
        else{
          confirma.setCustomValidity('As Senhas Não Conferem');
        }
        function Usuariovalidado(){

          alert("Usuário criado com sucesso!");
        }
      }        
    </script>
    <title>Cadastre-se</title>
</head>
<body>
<?php
  include('nav.html');
  include('conexao.php');

  $sql = "SELECT ID_Curso, Nome_Curso FROM curso;";
  $result = mysqli_query($mysqli, $sql);


?>
      <div class="row">
        <div class="col-4"></div>
        <div class="col-4">
            <center><h1>Cadastro</h1></center>
            
                <div class="form-group">
                  <form action="cadastro.php" onsubmit="Usuariovalidado();" method="POST">
                    <label for="nome">Nome Completo:</label>
                    <input class="form-control" type="text" id="ID" name="nome" placeholder="Digite seu nome completo..." required name>
                </div>
                
                <div class="form-group">
                  <label for="data">Data de nascimento:</label>
                  <input class="form-control" type="date" id="data" name="data" >
              </div>

              <div class="form-group">
                  <label for="curso">Curso de Graduação:</label>
                  <select class="form-control" id="curso" name="curso" required name>
                    <option value="Selecione" selected>Selecione um curso...</option>
                    <?php 
                      while($dados = mysqli_fetch_assoc($result)){
                        ?>
                        <option value="<?php echo $dados ['ID_Curso']?>">
                        <?php echo $dados['Nome_Curso']?>
                      </option>
                      <?php
                        }
                      ?>  
                  </select>
              </div>

                <div cLass="form-group">
                    <label for="senha">Senha:</label>
                    <input class="form-control" type="password" id="senha" name="senha" placeholder="Digite sua senha..." onchange='ConfereSenha();' required name>
                </div>
                <div cLass="form-group">
                    <label for="confirma">Confirmar senha:</label>
                    <input class="form-control" type="password" id="confirma" name="confirma" placeholder="Confirme sua senha..." onchange='ConfereSenha();' required name>
                </div>

                <div class="form-group text-center">
                    <button type="submit" class="btn">Cadastrar</button>
                    <p>Já possui cadastro? Faça o<a href="LoginView.php"> Login</p></a>
                  </form>
                </div>
            
        </div>
        </div>  
<script src="js/jquery-3.3.1.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
</body>
</html>