<?php 

include('conexao.php');

$nome=$_POST['pnome'];
$pdata=$_POST['pdata'];
$sexo=$_POST['psexo'];
$cep=$_POST['cep'];
$uf=$_POST['estado'];
$cidade=$_POST['cidade'];
$endereco=$_POST['endereco'];
$bairro=$_POST['bairro'];
$com=$_POST['complemento'];
$telefone=$_POST['telefone'];
$email=$_POST['email'];
$peso=$_POST['peso'];
$altura=$_POST['altura'];
$fuma=$_POST['fuma'];
$bebe=$_POST['bebe'];
$hiper=$_POST['hiper'];
$diab=$_POST['diab'];
$dac=$_POST['dac'];
$outro=$_POST['doenca'];
$med=$_POST['med'];
$rem=$_POST['rem'];



$pac = "INSERT INTO paciente
(Nome_Paciente, DTN_Paciente,Sex_Paciente,CEP_Paciente,UF_Paciente,Cid_Paciente,End_Paciente,Bai_Paciente,Com_Paciente,Fone_Paciente,Email_Paciente,Pes_Paciente,Alt_Paciente,Fuma_Paciente,Bebe_Paciente,Hiper_Paciente,Diab_Paciente,Dac_Paciente,Doe_Paciente,Med_Paciente,Rem_Paciente) 
        VALUES ('$nome','$pdata','$sexo','$cep','$uf','$cidade','$endereco','$bairro','$com','$telefone','$email','$peso','$altura','$fuma','$bebe','$hiper','$diab','$dac','$outro','$med','$rem')";

if(mysqli_query($mysqli, $pac)){
    header('location: homeView.php');
}
else{
    echo "Erro".mysqli_connect_error($mysqli);
}

mysqli_close($mysqli);



?>