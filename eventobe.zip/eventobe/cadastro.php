<?php 

include('conexao.php');

$nome=$_POST['nome'];
$data=$_POST['data'];
$senha=$_POST['senha'];
$curso=$_POST['curso'];


$sql = "INSERT INTO usuario(FKID_Curso,Nome,DTN,Senha) VALUES ('$curso','$nome','$data','$senha')";

if(mysqli_query($mysqli, $sql)){
    header('location: Bemvindo.php');
}
else{
    echo "Erro".mysqli_connect_error($mysqli);
}

mysqli_close($mysqli);



?>