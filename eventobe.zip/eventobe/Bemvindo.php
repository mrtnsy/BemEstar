<?php
include('conexao.php');

if(isset($_POST['ID']) || isset($_POST['senha'])) {

    if(strlen($_POST['ID']) == 0) {
        echo "Preencha seu e-mail";
    } else if(strlen($_POST['senha']) == 0) {
        echo "Preencha sua senha";
    } else {

        $id = $mysqli->real_escape_string($_POST['ID']);
        $senha = $mysqli->real_escape_string($_POST['senha']);

        $sql_code = "SELECT * FROM usuario WHERE Cod_Usuario = '$id' AND Senha = '$senha'";
        $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: " . $mysqli->error);

        $quantidade = $sql_query->num_rows;

        if($quantidade == 1) {
            
            $usuario = $sql_query->fetch_assoc();

            if(!isset($_SESSION)) {
                session_start();
            }

            $_SESSION['id'] = $usuario['Cod_Usuario'];
            $_SESSION['nome'] = $usuario['Nome'];

            header("Location: homeView.php");

        } else {
            echo "Falha ao logar! ID ou senha incorretos";
        }

    }

}

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilo.css">

    <title>Bem-Vindo!</title>
</head>
<body>
   <?php include('nav.html'); ?>


   <center><h1>Bem-Vindo!<p>Para saber seu ID Contate o Adm da página. Ultilize ele e a senha que acabou de criar para acessar a plataforma.</p></h1></center>
   <center><p><strong style="color: red;"> Atenção:</strong> Não Perca seu ID, caso esqueça você deverá entrar em contato com o Administrador da página para recurá-lo.</p></center>
    <br>
    <br>
    <br>
      <div class="row">
        <div class="col-4"></div>
        <div class="col-4">
            
            
            <div class="form-group">
                <form action="" method="POST">
                        <label for="ID">ID:</label>
                        <input class="form-control" type="text" id="ID" name="ID" placeholder="Digite seu ID..." required name>
                    </div>
                    <div cLass="form-group">
                        <label for="senha">Senha:</label>
                        <input class="form-control" type="password" id="senha" name="senha" placeholder="Digite sua senha..." required name>
                    </div>
                    <div class="form-group text-center">
                        <button type="submit" class="btn">Logar</button>
                </form>
            </div>
            
        </div>
        </div>  
<script src="js/jquery-3.3.1.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
</body>
</html>