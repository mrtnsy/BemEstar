<?php
include('conexao.php');
include('protect.php');

$sql= "SELECT Cod_Paciente, Nome_Paciente FROM paciente";
$result=$mysqli->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <title>Pesquisa</title>
    <script>
        const INPUT_BUSCA = document.getElementbyId('input-busca');
        const TABELA_BEBIDAS = document.getElementbyId('tabela-paciente');

        INPUT_BUSCA.addEventListener('keyup', () =>{
            let expressao = INPUT_BUSCA.value.toLowerCase();

            let linhas = TABELAS_PACIENTE.getElementByTagName('tr');

            for(let posicao in linhas){
                if(true === isNaN(posicao)){
                    continue;

                    let conteudoDaLinha = Linhas[posicao].innerHTML.toLowerCase();

                    if(true === conteudoDaLinha.includes(expressao)){

                        linhas[posicao].style.display = '';
                    }
                    else{
                        linhas[posicao].style.display = 'none';
                    }
                }
            }
            console.log(posicao);
        })
    </script>
    <style>

        .barra-de-pesquisa{

            display: block;
            margin-bottom: 100px;
            width: 40%;
            height: calc(2.25rem + 2px);
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            border-radius: 1rem;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        .container{
            color
            margin: 4%;
            display: flex;
            align-items: center;
            justify-content: center;
        }


        .link{
            background-color: #297223;
            color: white;
            font-weight: bold;
            width: 100px;
            height: 50px;
            border: 1px solid rgb(239, 224, 224);
            border-radius: 10px;
        }

        .link:hover{
            background-color: #3da233;

        }

        .content-table{
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            min-width: 115%;
        }

        .content-table thead tr{
            background-color: rgb(46, 109, 46);
            color: aliceblue;
            text-align: left;
            font-weight: bold;
        }

        .content-table th, td{
            padding: 12px 25px;
        
        }

        .content-table tbody tr {
            border-left: 1px solid #dddddd;
            border-right: 1px solid #dddddd;
        }

        .content-table tbody tr:nth-of-type(even){
            background-color:#e5fae2;
        }

        .content-table tbody tr:last-of-type{
            border-bottom: 2px solid #297223;
        }

        .pesquisa{
            font-size: large;
            font-weight: bold;
        }

        .id{
            border-top-left-radius: 8px;
          
        }

        .paciente{
            border-top-right-radius: 8px;
            
        }

    </style>


</head>
<body>
<?php include('nav_session.html')?>
    <header class="topo">
        <label for="pesquisa" class="pesquisa" style="margin-left: 31%;">Busca: </label>
        <center>
            <input class="barra-de-pesquisa" type="search" placeholder="Insira o nome do paciente desejado">
        </center>
    </header>
    <main class="container">
            <table class="content-table">
                <thead>
                    <tr>
                        
                        
                        <th class = "id">ID</th>
                        <th class = "">Paciente</th>
                        <th class = "paciente">Exame</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    
                        while($usuario_data = mysqli_fetch_assoc($result)){

                            echo "<tr>";
                            echo "<td>".$usuario_data['Cod_Paciente']."</td>";
                            echo "<td>".$usuario_data['Nome_Paciente']."</td>";?>
                            <td><a href="Exame.php">Criar ou Editar</a></td><?php
                            
                            
                        }
                    ?>
                </tbody>
            </table>

           

    </main>
    <script src="js/jquery-3.3.1.slim.min.js"></script>
    <script src="js/bootstrap.min.js"></script>  
</body>
</html>