<?php 

    include("protect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="estilo.css">
<!--  <script>
        $("#btn").on("click", function(){
    var numCep = $("#cep").val();
    var url = "https://viacep.com.br/ws/"+numCep+"/json";

    $.ajax({
        url: url,
        type: "get",
        dataType: "json",

        success:function(dados){
            console.log(dados);
            $("#uf").val(dados.uf);
            $("#cidade").val(dados.localidade);
            $("#logradouro").val(dados.logradouro);
            $("#bairro").val(dados.bairro);
        }
    })


})
    </script> -->
    <style>
        .borda{
            width: 100%;
            margin-bottom: 75px;
            padding: 20px;
            border-width: 1px;
            border-radius: 3px;
            border-color: grey;
            border-style: outset;
            box-shadow: 10px 10px greenyellow;
    
        }
    </style>
    <title>Cadastro Paciente</title>
</head>
<body>
    <?php include('nav_session.html'); ?>
    </header>

    <div class="row">
        <div class="col-4"></div>
        <div class="col-4">

                <h1 class="cadastro">Cadastre o Paciente:</h1>

               
                    
                        <form action="CadastroPaciente.php" method="POST">
                            <p>Identificação:</p>
                            <div class="borda">

                                <div class="form-group">
                                    <label for="fname">Nome Completo</label>
                                    <input class="form-control" type="text" id="fname" name="pnome">
                                </div>

                                <div class="form-group">
                                    <label for="bdate">Data de Nascimento</label>
                                    <input class="form-control" type="date"name="pdata">
                                </div>


                                <a>Sexo:</a>
                                <div class="form-group">
                                    <input type="radio" name="psexo" value="Masculino">
                                    <label for="masc">Masculino</label>

                                    <input type="radio" id="fem" name="psexo" value="Feminino">
                                    <label for="fem">Feminino</label>
                            
                                    <input type="radio" id="outro" name="psexo" value="Outro">
                                    <label for="outro">Outro</label>
                                </div>

                                <div class="form-group ">
                                        <label for="cep">CEP:</label>
                                        <input class="form-control col-4" type="text"  name="cep" placeholder="CEP">
                                        <!--<button type="submit" id="btn" class="btn btn-custom"><svg class="bi bi-chevron-right" width="32" height="32" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M6.646 3.646a.5.5 0 01.708 0l6 6a.5.5 0 010 .708l-6 6a.5.5 0 01-.708-.708L12.293 10 6.646 4.354a.5.5 0 010-.708z" clip-rule="evenodd"/></svg>
                                        </button> -->
                                   
                                </div>

                                <div class="form-group">
                                <label for="estado">Estado</label>
                                <select class="form-control" name="estado">
                                    <option selected>Selecione seu estado...</option>
                                    <option value="AC">Acre</option>
                                    <option value="AL">Alagoas</option>
                                    <option value="AP">Amapá</option>
                                    <option value="AM">Amazonas</option>
                                    <option value="BA">Bahia</option>
                                    <option value="CE">Ceará</option>
                                    <option value="DF">Distrito Federal</option>
                                    <option value="ES">Espírito Santo</option>
                                    <option value="GO">Goiás</option>
                                    <option value="MA">Maranhão</option>
                                    <option value="MT">Mato Grosso</option>
                                    <option value="MS">Mato Grosso do Sul</option>
                                    <option value="MG">Minas Gerais</option>
                                    <option value="PA">Pará</option>
                                    <option value="PB">Paraíba</option>
                                    <option value="PR">Paraná</option>
                                    <option value="PE">Pernambuco</option>
                                    <option value="PI">Piauí</option>
                                    <option value="RJ">Rio de Janeiro</option>
                                    <option value="RN">Rio Grande do Norte</option>
                                    <option value="RS">Rio Grande do Sul</option>
                                    <option value="RO">Rondônia</option>
                                    <option value="RR">Roraima</option>
                                    <option value="SC">Santa Catarina</option>
                                    <option value="SP">São Paulo</option>
                                    <option value="SE">Sergipe</option>
                                    <option value="TO">Tocantins</option>
                                    <option value="EX">Estrangeiro</option>
                                </select>
                                </div>

                                <div class="form-group">
                                    <label for="cep">Cidade:</label>
                                    <input class="form-control " type="text" name="cidade" placeholder="Cidade" >
                                </div>

                                <div class="form-group">
                                    <label for="cep">Endereço:</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control col-8" placeholder="Logradouro" name="endereco" >
                                        <input type="text" class="form-control col-4" placeholder="Número" id="numero" name="endereco">
                            
                                    </div>
                                </div>

                                <div class="form-grounp">
                                    <label for="cep">Bairro:</label>
                                    <input type="text" class="form-control " placeholder="Bairro" name="bairro" >
                                </div>
                                        

                                <div class="form-group">
                                    <label for="complemento">Complemento</label>
                                    <input class="form-control" type="text" id="complemento" name="complemento">
                                </div>

                                <div class="form-group">
                                    <label for="telefone">Telefone:</label>
                                    <input type="tel" class="form-control" name="telefone" placeholder="(xx)xxxxx-xxxx">
                                </div>

                                <div class="form-group">
                                    <label for="email">E-mail</label>
                                    <input class="form-control" type="text" name="email">
                                </div>
                            </div>
                            



                            <p>Dados antropométricos:</p>
                            <div class="borda">
                                <div class="form-group">
                                    <label for="peso">Peso (KG)</label>
                                    <input class="form-control" type="number" step="0.01" id="peso" name="peso"><p>Kg</p>
                                </div>

                                <div class="form-group">
                                    <label for="altura">Altura (Metro)</label>
                                    <input class="form-control" type="number" step="0.01" id="altura" name="altura">
                                </div>
                            </div>

                            <p>Dados clínicos:</p>
                            <div class="borda">

                                <div class="form-group">                                   
                                    <a>Fumante:</a>
                                    <select class="form-control" name="fuma">
                                        <option selected>Selecione uma opção</option>
                                        <option value="0">Não</option>
                                        <option value="1">Sim</option>
                                    </select>                                 
                                </div>

                                <div class="form-group">                                   
                                    <a>Bebidas Alcoólicas:</a>
                                    <select class="form-control" name="bebe">
                                        <option selected>Selecione uma opção</option>
                                        <option value="0">Não</option>
                                        <option value="1">Sim</option>
                                    </select>                                     
                                </div>  

                                <div class="form-group">
                                    <label>Hipertensão:</label>
                                    <select class="form-control" name="hiper">
                                        <option selected>Selecione uma opção</option>
                                        <option value="0">Não</option>
                                        <option value="1">Sim</option>
                                    </select>  
                                </div>

                                <div class="form-group">                                   
                                    <a>Diabetes:</a>
                                    <select class="form-control" name="diab">
                                        <option selected>Selecione uma opção</option>
                                        <option value="0">Não</option>
                                        <option value="true">Sim</option>
                                    </select>  
                                </div>     

                                <div class="form-group">   
                                    <a>Doença cardíaca:</a>
                                    <select class="form-control" name="dac">
                                        <option selected>Selecione uma opção</option>
                                        <option value="0">Não</option>
                                        <option value="true">Sim</option>
                                    </select>  
                                </div>

                                <div class="form-group">
                                    <label for="doenca">Outras:</label>
                                    <input class="form-control" type="text" name="doenca">
                                </div>

                                <div class="form-group">
                                    <a for="medicacao">Medicações:</a>
                                    <select class="form-control" name="med">
                                        <option selected>Selecione uma opção</option>
                                        <option value="0">Não</option>
                                        <option value="true">Sim</option>
                                    </select>  
                                </div>

                                <div class="form-group">
                                    <label for="doenca">Quais:</label>
                                    <input class="form-control" type="text" name="rem">
                                </div>

                               <!--<div class="form-group">
                                    <label for="glicemia">Glicemia (mg/dL)</label>
                                    <input class="form-control" type="number" id="glicemia" name="glicemia">
                                </div>

                                <div class="form-group">
                                    <label for="colesterol">Colesterol (mg/dL)</label>
                                    <input class="form-control" type="number" id="colesterol" name="colesterol">
                                </div>  

                                <div class="form-group">
                                    <label for="pressao">Pressao Arterial:</label>
                                    <input class="form-control" type="number" id="pressao" name="pressao"><a>X</a><input type="number" id="mmhg" name="mmhg"><a>mmHg</a>
                                </div> -->
                                
                                <div class="text-center">
                                    <button type="submit" class="btn ">Cadastrar</button>
                                </div>
                        </form>

                    
                      
                  

    
      
    </div> 

<script src="js/jquery-3.3.1.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>  
</body>
</html>